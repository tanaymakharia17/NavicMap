from django.contrib import admin
from . models import *

#admin.site.register(Country)
# admin.site.register(Books)
# admin.site.register(TableContents)
#admin.site.register(Node)